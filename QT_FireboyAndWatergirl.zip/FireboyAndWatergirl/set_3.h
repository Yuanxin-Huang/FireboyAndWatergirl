#ifndef SET_3_H
#define SET_3_H

#include <QMainWindow>

class set_3 : public QMainWindow
{
    Q_OBJECT
public:
    explicit set_3(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent*);

signals:
    void set_3Back();
    void endless_open();
    void endless_close();
};

#endif // SET_3_H
