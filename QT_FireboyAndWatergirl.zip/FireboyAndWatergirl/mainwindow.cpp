#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QPainter>
#include<mypushbutton.h>
#include<QDebug>
#include<QTimer>
#include<QSoundEffect>
int endless_judge=0;
double speed=0.1;
double maxspeed=1.5;
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{   //开始界面
    ui->setupUi(this);
    this->setFixedSize(800,600);//游戏界面大小固定
    this->setWindowIcon(QPixmap(":/image/min.jpg"));//窗口图标
    this->setWindowTitle("森林冰火人");//窗口名称

    //设置遮罩，按钮按下主界面变灰效果
    shade = new shadewindow;
    shade->setParent(this,Qt::FramelessWindowHint | Qt::Window);//设置父窗口为本窗口，移除标题栏边框|设定本窗口为顶级窗口
    //shade->setGeometry(0, 0, 1, 1);
    //shade->hide();

    //播放音乐,做了一些改动
    QSoundEffect *startSound=new QSoundEffect(this);//:/image/LevelMusic.wav
    startSound->setSource(QUrl::fromLocalFile(":/image/LevelMusic.wav"));
    startSound->setLoopCount(100); //循环次数
    startSound->setVolume(0.25f); //音量 0~1之间
    startSound->play();


    //开始按钮
    MyPushButton *startbtn=new MyPushButton(":/image/play_final.PNG",0.5,0.5);
    startbtn->setParent(this);
    startbtn->move(this->width()*0.5-startbtn->width()*0.5,400);
    //游戏界面
    //选择界面
    cho=new Choose;
    connect(cho,&Choose::chooseBack,this,[=](){
        cho->hide();
        shade->hide();
    });
    connect(startbtn,&MyPushButton::clicked,[=](){
        startbtn->zoom1();
        startbtn->zoom2();
        cho->show();
        shade->show();
    });
   //第一关

    connect(cho,&Choose::choose_1,[=](){
        cho->hide();
        shade->hide();
        //开始游戏
        QTimer::singleShot(100,this,[=](){//100ms后调用这个lambda函数
            gam1=new firstgame;
            gam1->reset();
            this->hide();
            gam1->show();

            //连接第一关的槽函数
            win1_1=new winend;
            connect(gam1,&firstgame::winend1,[=](){
                shade->show();
                win1_1->show();
            });
            connect(win1_1,&winend::CloseWinend,[=](){
                gam1->reset();
                gam1->hide();
                win1_1->close();
                shade->hide();
                this->show();
             });
           //winend2
            win1_2=new winend2;
            connect(gam1,&firstgame::winend2,[=](){
                shade->show();
                win1_2->show();
            });
            connect(win1_2,&winend2::CloseWinend2,[=](){
                gam1->reset();
                gam1->hide();
                win1_2->close();
                shade->hide();
                this->show();
             });
            //loseend
            lose=new loseend;
            connect(gam1,&firstgame::loseend1,[=](){
                shade->show();
                lose->show();
            });
            connect(lose,&loseend::menus,[=](){
                gam1->reset();
                gam1->hide();
                lose->hide();
                shade->hide();
                this->show();
            });
            connect(lose,&loseend::retrys,[=](){
                gam1->reset();
                lose->hide();
                shade->hide();
            });
        });
    });
    //第二关
    connect(cho,&Choose::choose_2,[=](){
        cho->hide();
        shade->hide();
        //开始游戏
        QTimer::singleShot(100,this,[=](){//100ms后调用这个lambda函数
            gam2=new game;
            gam2->reset();
            this->hide();
            gam2->show();

            //连接第二关的槽函数
            win2_1=new winend;
            connect(gam2,&game::winend1,[=](){
                shade->show();
                win2_1->show();
            });
            connect(win2_1,&winend::CloseWinend,[=](){
                gam2->reset();
                gam2->hide();
                win2_1->close();
                shade->hide();
                this->show();
             });
                    //winend2
                    win2_2=new winend2;
                    connect(gam2,&game::winend2,[=](){
                        shade->show();
                        win2_2->show();
                    });
                    connect(win2_2,&winend2::CloseWinend2,[=](){
                        gam2->reset();
                        gam2->hide();
                        win2_2->close();
                        shade->hide();
                        this->show();
                    });
                    //loseend
                    connect(gam2,&game::loseend1,[=](){
                        shade->show();
                        lose->show();
                    });
                    connect(lose,&loseend::menus,[=](){
                        gam2->reset();
                        gam2->hide();
                        lose->hide();
                        shade->hide();
                        this->show();
                    });
                    connect(lose,&loseend::retrys,[=](){
                        gam2->reset();
                        lose->hide();
                        shade->hide();
                    });
                });
            });


    //第三关
    connect(cho,&Choose::choose_3,[=](){
        cho->hide();
        shade->hide();
        //开始游戏
        QTimer::singleShot(100,this,[=](){//100ms后调用这个lambda函数
            gam3=new thirdgame;
            gam3->reset();
            this->hide();
            gam3->show();

            //连接第三关的槽函数
            win3_1=new winend;
            connect(gam3,&thirdgame::winend1,[=](){
                shade->show();
                win3_1->show();
            });
            connect(win3_1,&winend::CloseWinend,[=](){
                gam3->reset();
                gam3->hide();
                win3_1->close();
                shade->hide();
                this->show();
            });
            //winend2
            win3_2=new winend2;
            connect(gam3,&thirdgame::winend2,[=](){
                shade->show();
                win3_2->show();
            });
            connect(win3_2,&winend2::CloseWinend2,[=](){
                gam3->reset();
                gam3->hide();
                win3_2->close();
                shade->hide();
                this->show();
            });
            //loseend
            connect(gam3,&thirdgame::loseend1,[=](){
                shade->show();
                lose->show();
            });
            connect(lose,&loseend::menus,[=](){
                gam3->reset();
                gam3->hide();
                lose->hide();
                shade->hide();
                this->show();
            });
            connect(lose,&loseend::retrys,[=](){
                gam3->reset();
                lose->hide();
                shade->hide();
            });
        });
    });

    //set button
    se=new set_new;
    MyPushButton *setbtn=new MyPushButton(":/image/set-removebg-preview.png",0.15,0.15);
    setbtn->setParent(this);
    setbtn->move(this->width()-190,420);
    connect(se,&set_new::set_newBack,this,[=](){
        se->hide();
        shade->hide();
    });
    connect(setbtn,&MyPushButton::clicked,[=](){
        setbtn->zoom1();
        setbtn->zoom2();
        se->show();
        shade->show();
       });
    //背景音乐
    set1=new set;
    connect(set1,&set::setBack,this,[=](){
        set1->hide();
    });
    connect(set1,&set::stopmusic,this,[=](){
        startSound->stop();
    });
    connect(set1,&set::playmusic,this,[=](){
        startSound->play();
        startSound->setLoopCount(100);
    });
    connect(se,&set_new::bgm_set,[=](){
        set1->show();
    });
    //难度选择
    set2=new set_2;
    connect(set2,&set_2::set_2Back,this,[=](){
        set2->hide();
    });
    connect(set2,&set_2::easy_choose,this,[=](){
        speed=0.1;
        maxspeed=1.5;
    });
    connect(set2,&set_2::normal_choose,this,[=](){
        speed=0.2;
        maxspeed=3.5;
    });
    connect(set2,&set_2::diff_choose,this,[=](){
        speed=0.5;
        maxspeed=5;
    });
    connect(se,&set_new::difficult_set,[=](){
       set2->show();
    });
    //无敌模式

    set3=new set_3;
    connect(set3,&set_3::set_3Back,this,[=](){
        set3->hide();
    });
    connect(set3,&set_3::endless_open,this,[=](){
        endless_judge=1;
    });
    connect(set3,&set_3::endless_close,this,[=](){
        endless_judge=0;
    });
    connect(se,&set_new::endless_set,[=](){
        set3->show();
    });

    //questionButton
    mo=new more;
    MyPushButton *questionbtn=new MyPushButton(":/image/more-removebg-preview.png",0.15,0.15);
    questionbtn->setParent(this);
    questionbtn->move(-110,375);
    connect(mo,&more::moreBack,this,[=](){
        mo->hide();
        shade->hide();
    });
    connect(questionbtn,&MyPushButton::clicked,[=](){
        questionbtn->zoom1();
        questionbtn->zoom2();
        mo->show();
        shade->show();
    });
}
void MainWindow::paintEvent(QPaintEvent*)
{
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/image/start_final.jpg");
    painter.drawPixmap(0,0,pix);
}
MainWindow::~MainWindow()
{
    delete ui;
}

