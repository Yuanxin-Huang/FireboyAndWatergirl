#ifndef SHADEWINDOW_H
#define SHADEWINDOW_H

#include <QWidget>

class shadewindow : public QWidget
{
    Q_OBJECT
public:
    explicit shadewindow(QWidget *parent = nullptr);//explicit 禁止隐性类型转换 构造函数
};

#endif // SHADEWINDOW_H
