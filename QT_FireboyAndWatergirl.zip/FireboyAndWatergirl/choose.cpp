#include "choose.h"
#include "ui_choose.h"
#include"mypushbutton.h"
#include<QPainter>
#include<QTimer>
Choose::Choose(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Choose)
{
    this->setFixedSize(1000,540);
    this->setWindowTitle("设置");
    this->setWindowModality(Qt::ApplicationModal);
    this->setWindowOpacity(1); //窗口整体透明度，0-1 从全透明到不透明
    this->setWindowFlags(Qt::FramelessWindowHint); //设置无边框风格
    this->setAttribute(Qt::WA_TranslucentBackground); //设置背景透明，允许鼠标穿透
    //返回按钮
    MyPushButton *backbtn=new MyPushButton(":/image/back_set.PNG",1.0,1.0);
    backbtn->setParent(this);
    backbtn->move(this->width()*0.5-53,358);

    connect(backbtn,&MyPushButton::clicked,[=]{
        backbtn->zoom1();
        backbtn->zoom2();
        //延时
        QTimer::singleShot(100,this,[=](){
            emit this->chooseBack();
        });
    });
    //第一关按钮
    MyPushButton *btn1=new MyPushButton(":/image/choose1.PNG",1.0,1.0);
    btn1->setParent(this);
    btn1->move(this->width()*0.5-53,220);

    connect(btn1,&MyPushButton::clicked,[=]{
        btn1->zoom1();
        btn1->zoom2();
        //延时
        QTimer::singleShot(100,this,[=](){
            emit this->choose_1();
        });
    });
    //第二关按钮
    MyPushButton *btn2=new MyPushButton(":/image/choose2.PNG",1.0,1.0);
    btn2->setParent(this);
    btn2->move(this->width()*0.5-53,266);

    connect(btn2,&MyPushButton::clicked,[=]{
        btn2->zoom1();
        btn2->zoom2();
        //延时
        QTimer::singleShot(100,this,[=](){
            emit this->choose_2();
        });
    });
    //第三关按钮
    MyPushButton *btn3=new MyPushButton(":/image/choose3.PNG",1.0,1.0);
    btn3->setParent(this);
    btn3->move(this->width()*0.5-53,312);

    connect(btn3,&MyPushButton::clicked,[=]{
        btn3->zoom1();
        btn3->zoom2();
        //延时
        QTimer::singleShot(100,this,[=](){
            emit this->choose_3();
        });
    });
}
void Choose::paintEvent(QPaintEvent*)
{
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/image/block.PNG");
    painter.drawPixmap(200,100,600,381,pix);
}

Choose::~Choose()
{
    delete ui;
}
