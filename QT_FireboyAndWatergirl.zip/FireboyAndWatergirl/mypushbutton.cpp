#include "mypushbutton.h"
#include<QDebug>
#include<QPropertyAnimation>
MyPushButton::MyPushButton(QString normalImage,double x,double y)
{
    this->normalImgPath=normalImage;

    QPixmap pix;
    bool ret=pix.load(normalImgPath);//加载图片
    if(!ret)
    {
        qDebug()<<"图片加载失败";
        return;
    }
    this->setFixedSize(pix.width(),pix.height());

    //设置不规则图片
    this->setStyleSheet("QPushButton{border:0px;}");//隐藏边框

    //设置图标
    this->setIcon(pix);//？？？？？？？？？？？？？？？？？？？？？？？？？？？

    this->setIconSize(QSize(pix.width()*x,pix.height()*y));//便于调整按钮尺寸
    /*
    QRect pix_rect=pix.rect();
    x=pix_rect.x();
    y=pix_rect.y();
    wid=pix_rect.width();
    hei=pix_rect.height();*/
}
void MyPushButton::zoom1()//按钮移动
{
    QPropertyAnimation * animation=new QPropertyAnimation(this,"geometry");
    animation->setDuration(200);//动画持续时间
    animation->setStartValue(QRect(this->x(),this->y(),this->width(),this->height()));
    animation->setEndValue(QRect(this->x(),this->y()+10,this->width(),this->height()));//实现点击按钮动画
    animation->setEasingCurve(QEasingCurve::OutBounce);//按钮移动曲线
    animation->start();
     /*可删？？？？？？？？？？？？？？？ 且 ？有问题
    if(this->y()<400)
    {
        counter++;
    }

    if(counter>=2)//？？？？？？？？？？？？？？？？？？？？
    {
        //qDebug("越界");
        this->move(this->x(),230);
    }*/
}
void MyPushButton::zoom2()//按钮动画复位
{
    QPropertyAnimation * animation=new QPropertyAnimation(this,"geometry");
    animation->setDuration(200);
    animation->setStartValue(QRect(this->x(),this->y()+10,this->width(),this->height()));
    animation->setEndValue(QRect(this->x(),this->y(),this->width(),this->height()));
    animation->setEasingCurve(QEasingCurve::OutBounce);
    animation->start();
/*
    QPainter painter(this);
    painter.setPen(QColor("red"));
    painter.drawRect(x,y,wid,hei);*/
}
