#ifndef MYPUSHBUTTON_H
#define MYPUSHBUTTON_H

#include <QPushButton>
//#include<QPainter>
//#include<QRect>
class MyPushButton : public QPushButton
{
    Q_OBJECT
public:
    //explicit MyPushButton(QWidget *parent = nullptr);
    MyPushButton(QString normalImage,double x,double y);
    QString normalImgPath;//按钮图片路径
    QString pressImgPath;//按下后按钮图片路径
    int counter=0;

    void zoom1();
    void zoom2();

  //  int x,y,wid,hei;


};

#endif // MYPUSHBUTTON_H
