#include "set.h"
#include<QPainter>
#include"mypushbutton.h"
#include<QDebug>
#include<QPoint>
#include<QMouseEvent>
#include<QTimer>
set::set(QWidget *parent) : QMainWindow(parent)
{
    this->setFixedSize(1000,700);
    this->setWindowTitle("背景音乐");
    this->setWindowModality(Qt::ApplicationModal);//模态类型为应用程序模态 阻塞所有应用程序窗口的交互
    this->setWindowOpacity(1); //窗口整体透明度，0-1 从全透明到不透明
    this->setWindowFlags(Qt::FramelessWindowHint); //设置无边框风格
    this->setAttribute(Qt::WA_TranslucentBackground); //设置背景透明，允许鼠标穿透
    //返回按钮
    MyPushButton *back1btn=new MyPushButton(":/image/last_final.PNG",1.0,1.0);
    back1btn->setParent(this);
    back1btn->move(this->width()*0.5-75,415);

    connect(back1btn,&MyPushButton::clicked,[=]{
        back1btn->zoom1();
        back1btn->zoom2();
        //延时
        QTimer::singleShot(100,this,[=](){
            emit this->setBack();
        });

    });
    //music
    int num=0;
    MyPushButton *musicbtn=new MyPushButton(":/image/music_open.PNG",1.0,1.0);
    musicbtn->setParent(this);
    musicbtn->move(this->width()*0.5-60,300);
    connect(musicbtn,&MyPushButton::clicked,[=]()mutable{//易变
        num++;
        if(num%2==1)
        emit this->stopmusic();
        else
        emit this->playmusic();
        musicbtn->zoom1();
        musicbtn->zoom2();
    });
}
void set::paintEvent(QPaintEvent*)
{
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/image/block.PNG");
    painter.drawPixmap(210,210,600,326,pix);
}

